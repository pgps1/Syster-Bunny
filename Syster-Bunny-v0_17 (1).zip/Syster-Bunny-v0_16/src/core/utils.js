// Funções utilitárias compartilhadas pelo jogo.
export function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

// Acima deste valor de saciedade ela recusa comida (fed decai 0,3/s e quase nunca fica em exatamente 100).
export const FULL_THRESHOLD = 95;

export function pick(list) {
  return list[Math.floor(Math.random() * list.length)];
}
