// Catálogo de dados do Syster Bunny.
// Estes dados ficam separados da lógica que controla compras e inventário.

export const decorationItems = [
  ["blank", "Cobertinha", 15],
  ["cush", "Almofada verde", 20],
  ["lamp", "Luminária", 25],
  ["rug", "Tapete rosa", 30],
  ["fan", "Ventilador", 35]
];

export const foods = [
 {id:"apple",name:"Maçã",emoji:"🍎",cat:"fruits",price:3,hunger:16},
 {id:"banana",name:"Banana",emoji:"🍌",cat:"fruits",price:3,hunger:17},
 {id:"strawberry",name:"Morango",emoji:"🍓",cat:"fruits",price:4,hunger:12},
 {id:"grapes",name:"Uvas",emoji:"🍇",cat:"fruits",price:4,hunger:13},
 {id:"pear",name:"Pera",emoji:"🍐",cat:"fruits",price:4,hunger:15},
 {id:"carrot_food",name:"Cenoura",emoji:"🥕",cat:"vegetables",price:4,hunger:20},
 {id:"broccoli",name:"Brócolis",emoji:"🥦",cat:"vegetables",price:5,hunger:18},
 {id:"lettuce",name:"Alface",emoji:"🥬",cat:"vegetables",price:4,hunger:12},
 {id:"corn",name:"Milho",emoji:"🌽",cat:"vegetables",price:5,hunger:18},
 {id:"pumpkin",name:"Abóbora",emoji:"🎃",cat:"vegetables",price:6,hunger:22},
 {id:"cookie",name:"Biscoito",emoji:"🍪",cat:"sweets",price:6,hunger:7},
 {id:"cupcake",name:"Cupcake",emoji:"🧁",cat:"sweets",price:8,hunger:8},
 {id:"cake",name:"Fatia de bolo",emoji:"🍰",cat:"sweets",price:9,hunger:9},
 {id:"candy",name:"Bala",emoji:"🍬",cat:"sweets",price:3,hunger:3},
 {id:"water",name:"Água",emoji:"💧",cat:"drinks",price:2,hunger:5},
 {id:"milk",name:"Leite",emoji:"🥛",cat:"drinks",price:5,hunger:9},
 {id:"juice",name:"Suco",emoji:"🧃",cat:"drinks",price:6,hunger:8},
 {id:"smoothie",name:"Vitamina de frutas",emoji:"🥤",cat:"drinks",price:8,hunger:12}
];
