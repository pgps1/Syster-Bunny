// Camada única de persistência. Nenhum sistema do jogo precisa acessar localStorage diretamente.
const TRUST_KEY = "sb_trust";
const SAVE_KEY = "sb_save";
const TIME_KEY = "sb_time";

function readJSON(key) {
  try { const raw = localStorage.getItem(key); return raw === null ? null : JSON.parse(raw); }
  catch { return null; }
}
function write(key, value) {
  try { localStorage.setItem(key, String(value)); } catch { /* armazenamento indisponível */ }
}
export function loadTrust(fallback = 0) {
  try { const raw = localStorage.getItem(TRUST_KEY); return raw === null ? fallback : Math.max(0, Math.min(100, Number(raw) || 0)); }
  catch { return fallback; }
}
export function saveTrust(value) { write(TRUST_KEY, value); }
export function loadGameSave() { return readJSON(SAVE_KEY); }
export function saveGameSave(data) {
  try { localStorage.setItem(SAVE_KEY, JSON.stringify(data)); } catch { /* armazenamento indisponível */ }
}
export function loadGameTime(fallback = 0) {
  try { const raw = localStorage.getItem(TIME_KEY); return raw === null ? fallback : Math.max(0, Number(raw) || 0); }
  catch { return fallback; }
}
export function saveGameTime(value) { write(TIME_KEY, Number(value).toFixed(1)); }
