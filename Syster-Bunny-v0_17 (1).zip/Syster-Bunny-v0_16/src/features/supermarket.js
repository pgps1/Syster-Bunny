// Supermercado, despensa, geladeira e alimentação.
import { FULL_THRESHOLD } from "../core/utils.js";
export function initSupermarket({ $, foods, getState, setCoins, setFed, setEat, setLastDragEnd, actions }) {
  const {say,talk,act,add,react,sv,set,pick,clamp,updShop}=actions;
  let marketCategory="fruits", fdrag=null, fNear=false;
  const state = () => getState();
  function inventoryTotal(){const inv=state().foodInventory;return Object.keys(inv).reduce((n,k)=>n+Math.max(0,parseInt(inv[k],10)||0),0);}
  function foodById(id){return foods.find(f=>f.id===id)||null;}
  function renderFridge(html,ids){
    $("fridgeItems").innerHTML=html||'<p class="market-note">A geladeira está vazia. Compre alimentos no supermercado!</p>' ;
    const slots=[[252,104],[278,104],[304,104],[252,136],[278,136],[304,136],[252,198],[278,198],[304,198],[252,228],[278,228],[304,228],[252,258],[278,258],[304,258]];let g="";
    ids.forEach((id,i)=>{const f=foodById(id);if(f&&i<slots.length)g+='<text data-drag="'+id+'" style="cursor:grab;touch-action:none;user-select:none" x="'+slots[i][0]+'" y="'+slots[i][1]+'" font-size="22" text-anchor="middle">'+f.emoji+'</text>';});
    $("fridgeFoods").innerHTML=g;
  }
  function renderPantry(){
    const inv=state().foodInventory;const ids=Object.keys(inv).filter(id=>(parseInt(inv[id],10)||0)>0);let html="";
    ids.sort((a,b)=>{const fa=foodById(a),fb=foodById(b);return (fa?fa.name:a).localeCompare(fb?fb.name:b,"pt-BR");});
    ids.forEach(id=>{const f=foodById(id),qty=parseInt(inv[id],10)||0;if(!f)return;html+='<div class="pantry-item"><span><span class="drag-food" data-drag="'+f.id+'" title="Arraste até a boca da Syster">'+f.emoji+'</span> <strong>'+f.name+'</strong> × '+qty+'</span><button type="button" data-feed="'+f.id+'">Oferecer</button></div>';});
    $("pantryItems").innerHTML=html||'<p class="market-note">Sua despensa está vazia. Escolha alguns alimentos no supermercado!</p>';renderFridge(html,ids);$("pantryCount").textContent=inventoryTotal()+" itens";
  }
  function renderMarket(){
    const list=foods.filter(f=>f.cat===marketCategory);let html="";
    list.forEach(f=>{html+='<div class="food-card"><span class="food-emoji">'+f.emoji+'</span><strong>'+f.name+'</strong><small>'+f.price+' moedas</small><button type="button" data-buy="'+f.id+'">Comprar +1</button></div>';});
    $("marketProducts").innerHTML=html;const cats=$("marketCats").querySelectorAll("button");
    for(let c=0;c<cats.length;c++)cats[c].classList.toggle("active",cats[c].getAttribute("data-category")===marketCategory);renderPantry();
  }
  function openMarket(){if(state().room!=="K"){say("O supermercado só pode ser acessado pela cozinha.");return;}$("marketPanel").hidden=false;$("marketToggle").setAttribute("aria-expanded","true");renderMarket();say("Bem-vindo ao supermercado! Escolha os alimentos para a despensa.");}
  function closeMarket(){$("marketPanel").hidden=true;$("marketToggle").setAttribute("aria-expanded","false");}
  function feedFood(fid){
    const f=foodById(fid);if(!f)return;const s=state();
    if(s.room!=="K"){say("Volte à cozinha para oferecer alimentos.");return;}
    if(s.her!=="K"){say("A Syster não está na cozinha. Toque no sino para chamá-la antes de oferecer comida.");return;}
    if(s.lock||s.sleeping){say("Espere a Syster terminar o que está fazendo.");return;}
    if(s.fed>=FULL_THRESHOLD){say("A Syster está sem fome e não quer mais comida agora. Guarde o alimento para depois!");talk("estou satisfeita… obrigada!",2400);return;}
    const inv=s.foodInventory,qty=parseInt(inv[f.id],10)||0;if(qty<1)return;inv[f.id]=qty-1;if(inv[f.id]<=0)delete inv[f.id];
    act();s.memories.food++;setFed(clamp(s.fed+f.hunger,0,100));add(1.5);react("happy");setEat(true);sv();set();renderPantry();say("A Syster comeu "+f.name.toLowerCase()+". A saciedade aumentou!");talk(pick(["nham, nham!","obrigada!","que delícia!","gostei disso!"]),2400);setTimeout(()=>setEat(false),1800);
  }
  function mouthNear(e){const m=$("mouth").getBoundingClientRect(),cx=m.left+m.width/2,cy=m.top+m.height/2;return Math.hypot(e.clientX-cx,e.clientY-cy)<58;}
  function moveGhost(e){const g=fdrag.g;g.style.left=e.clientX+"px";g.style.top=e.clientY+"px";const s=state(),near=s.her===s.room&&mouthNear(e);if(near!==fNear){fNear=near;g.classList.toggle("near",near);if(near)talk("aaah~",1200);}}
  function onDragMove(e){if(fdrag)moveGhost(e);}
  function endDrag(ok){window.removeEventListener("pointermove",onDragMove);window.removeEventListener("pointerup",onDragUp);window.removeEventListener("pointercancel",onDragCancel);const d=fdrag;if(!d)return;fdrag=null;const near=fNear;fNear=false;d.g.remove();setLastDragEnd(Date.now());if(ok&&near)feedFood(d.id);}
  function onDragUp(){if(fdrag)endDrag(true);}function onDragCancel(){if(fdrag)endDrag(false);}
  function feedHandler(e){const b=e.target.closest("button[data-feed]");if(b)feedFood(b.getAttribute("data-feed"));}
  $("marketToggle").onclick=openMarket;$("marketClose").onclick=closeMarket;
  $("marketCats").onclick=e=>{const b=e.target.closest("button[data-category]");if(!b)return;marketCategory=b.getAttribute("data-category");renderMarket();};
  $("marketProducts").onclick=e=>{const b=e.target.closest("button[data-buy]");if(!b)return;const f=foodById(b.getAttribute("data-buy"));if(!f)return;const s=state();if(s.coins<f.price){say("Você não tem moedas suficientes para comprar "+f.name+".");return;}setCoins(s.coins-f.price);s.foodInventory[f.id]=(parseInt(s.foodInventory[f.id],10)||0)+1;sv();updShop();renderPantry();say(f.emoji+" "+f.name+" foi guardado na despensa!");if(s.her==="K")talk("isso parece gostoso!",1800);};
  $("pantryItems").onclick=feedHandler;$("fridgeItems").onclick=feedHandler;
  document.addEventListener("pointerdown",e=>{const t=e.target.closest&&e.target.closest("[data-drag]");if(!t||fdrag)return;const f=foodById(t.getAttribute("data-drag"));if(!f)return;const s=state();
    if(s.her!=="K"||s.room!=="K"){say("A Syster não está na cozinha. Toque no sino para chamá-la antes de oferecer comida.");return;}
    if(s.lock||s.sleeping){say("Espere a Syster terminar o que está fazendo.");return;}
    if(s.fed>=FULL_THRESHOLD){say("A Syster está sem fome e não quer mais comida agora. Guarde o alimento para depois!");talk("estou satisfeita… obrigada!",2400);return;}
    e.preventDefault();const g=document.createElement("div");g.className="drag-ghost";g.textContent=f.emoji;document.body.appendChild(g);fdrag={id:f.id,g};moveGhost(e);window.addEventListener("pointermove",onDragMove);window.addEventListener("pointerup",onDragUp);window.addEventListener("pointercancel",onDragCancel);say("Arraste "+f.name.toLowerCase()+" até a boca da Syster.");
  });
  window.addEventListener("touchmove",e=>{if(fdrag)e.preventDefault();},{passive:false});
  renderMarket();
  return {closeMarket,openMarket,renderPantry,inventoryTotal,feedFood,isDragging:()=>!!fdrag,isNearMouth:()=>fNear};
}
