// Minijogo da caça às borboletas. Toda a lógica do minijogo fica isolada aqui.
export function initGardenGame({ $, getState, onReward, say, react, talk, pick }) {
  let gameLevel="easy",gameActive=false,gameScore=0,gameSeconds=45,gameClock=null,gameMotion=null,gameTargets=[],netDragging=false;
const gameConfig={easy:{count:4,speed:.42,radius:9},medium:{count:5,speed:.78,radius:7.5},hard:{count:6,speed:1.18,radius:6.2}};
function chooseGameLevel(level){if(gameActive)return;gameLevel=level;var buttons=$("gameLevels").querySelectorAll("button");for(var i=0;i<buttons.length;i++)buttons[i].classList.toggle("selected",buttons[i].getAttribute("data-level")===level);}
function gamePosition(el,xp,yp){el.style.left=xp+"%";el.style.top=yp+"%";}
function spawnButterflies(){
 var holder=$("butterflies");holder.innerHTML="";gameTargets=[];var cfg=gameConfig[gameLevel];
 for(var i=0;i<cfg.count;i++){
  var el=document.createElement("span");el.className="butterfly";el.textContent="🦋";
  var t={el:el,x:12+Math.random()*76,y:12+Math.random()*66,vx:(Math.random()-.5)*cfg.speed,vy:(Math.random()-.5)*cfg.speed};
  gamePosition(el,t.x,t.y);holder.appendChild(el);gameTargets.push(t);
 }
}
function updateGameStats(){$("gameScore").textContent="Capturas: "+gameScore;$("gameTime").textContent="Tempo: "+gameSeconds+"s";}
function stopGame(){gameActive=false;clearInterval(gameClock);clearInterval(gameMotion);gameClock=gameMotion=null;netDragging=false;$("net").classList.remove("dragging");$("gardenGameField").hidden=true;$("gameStats").hidden=true;$("gameLevels").hidden=false;$("gameStart").hidden=false;$("gameClose").hidden=false;}
function finishGame(){if(!gameActive)return;stopGame();var reward=Math.min(15,Math.floor(gameScore/2)+2);onReward(reward, Math.min(5,gameScore*.35));$("gameFinish").textContent="Fim da brincadeira! Você capturou "+gameScore+" borboleta(s) e ganhou "+reward+" moedas. A Syster adorou acompanhar você!";$("gameIntro").textContent="Escolha outro nível ou tente melhorar sua pontuação.";react(gameScore>=5?"happy":"curious");talk(gameScore>=5?"que divertido!":"gostei de brincar!",2600);}
function startGame(){
 if(getState().room!=="G"){say("A Caça às Borboletas só pode ser jogada no jardim.");return;}
 if(getState().her!=="G"){say("Toque no sino para chamar a Syster ao jardim antes de começar a brincadeira.");talk("me chama para o jardim?",2200);return;}
 if(getState().rainOn){say("Está chovendo! As borboletas se esconderam. Volte quando a chuva passar.");return;}
 if(getState().lock||getState().sleeping){say("A Syster precisa terminar o que está fazendo primeiro.");return;}
 gameActive=true;gameScore=0;gameSeconds=45;$("gameFinish").textContent="";$("gameIntro").textContent="Arraste a rede até uma borboleta para capturá-la!";$("gameLevels").hidden=true;$("gameStart").hidden=true;$("gameClose").hidden=true;$("gameStats").hidden=false;$("gardenGameField").hidden=false;gamePosition($("net"),78,78);spawnButterflies();updateGameStats();say("A brincadeira começou! Arraste a rede até as borboletas.");talk("oba! borboletas!",2200);
 gameClock=setInterval(function(){gameSeconds--;updateGameStats();if(gameSeconds<=0)finishGame()},1000);
 gameMotion=setInterval(function(){for(var i=0;i<gameTargets.length;i++){var t=gameTargets[i];t.x+=t.vx;t.y+=t.vy;if(t.x<8||t.x>92)t.vx*=-1;if(t.y<9||t.y>83)t.vy*=-1;t.x=Math.max(8,Math.min(92,t.x));t.y=Math.max(9,Math.min(83,t.y));gamePosition(t.el,t.x,t.y);}},90);
}
function moveNet(ev){if(!netDragging||!gameActive)return;var field=$("gardenGameField").getBoundingClientRect();var xp=Math.max(4,Math.min(96,(ev.clientX-field.left)/field.width*100));var yp=Math.max(5,Math.min(92,(ev.clientY-field.top)/field.height*100));gamePosition($("net"),xp,yp);var cfg=gameConfig[gameLevel];
 for(var i=gameTargets.length-1;i>=0;i--){var t=gameTargets[i];var dx=(xp-t.x)*field.width/100,dy=(yp-t.y)*field.height/100;if(Math.sqrt(dx*dx+dy*dy)<cfg.radius/100*Math.min(field.width,field.height)+23){t.el.remove();gameTargets.splice(i,1);gameScore++;updateGameStats();say("Boa! Você capturou uma borboleta!");if(gameScore%3===0)talk("mais uma!",1200);if(gameTargets.length===0)spawnButterflies();}}
 if(ev.cancelable)ev.preventDefault();
}
$("gameLevels").onclick=function(e){var level=e.target.getAttribute&&e.target.getAttribute("data-level");if(level)chooseGameLevel(level)};
$("gameStart").onclick=startGame;
$("gameClose").onclick=function(){stopGame();$("gamePanel").hidden=true;$("gameFinish").textContent="";};
$("net").addEventListener("pointerdown",function(e){if(!gameActive)return;netDragging=true;$("net").classList.add("dragging");$("net").setPointerCapture(e.pointerId);moveNet(e);e.preventDefault()});
$("net").addEventListener("pointermove",moveNet);
$("net").addEventListener("pointerup",function(){netDragging=false;$("net").classList.remove("dragging")});
$("net").addEventListener("pointercancel",function(){netDragging=false;$("net").classList.remove("dragging")});
$("net").addEventListener("keydown",function(e){if(!gameActive)return;var r=$("gardenGameField").getBoundingClientRect(),n=$("net").getBoundingClientRect();var xp=(n.left+n.width/2-r.left)/r.width*100,yp=(n.top+n.height/2-r.top)/r.height*100;if(["ArrowUp","ArrowDown","ArrowLeft","ArrowRight"].indexOf(e.key)>-1){e.preventDefault();var d=4;if(e.key==="ArrowUp")yp-=d;if(e.key==="ArrowDown")yp+=d;if(e.key==="ArrowLeft")xp-=d;if(e.key==="ArrowRight")xp+=d;gamePosition($("net"),Math.max(4,Math.min(96,xp)),Math.max(5,Math.min(92,yp)));netDragging=true;moveNet({clientX:r.left+xp/100*r.width,clientY:r.top+yp/100*r.height,cancelable:false,preventDefault:function(){}});netDragging=false;}});
  return { stopGame, finishGame, isActive: () => gameActive };
}
