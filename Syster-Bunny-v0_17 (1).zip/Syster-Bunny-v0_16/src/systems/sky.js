// Cálculos puros de cores e posições do céu. A passagem do tempo continua no controlador principal.
export const SKY = [[0,"#121638"],[5,"#1b1f4d"],[6,"#f2a982"],[7.5,"#bfe0f2"],[9,"#a9d8ef"],[16.5,"#a9d8ef"],[18,"#f5a56f"],[19.5,"#4a3f7a"],[21,"#121638"],[24,"#121638"]];

export function interpolateColor(a,b,t,clampFn=(v,min,max)=>Math.max(min,Math.min(max,v))) {
  t=clampFn(t,0,1);
  const rgb = c => [parseInt(c.substr(1,2),16),parseInt(c.substr(3,2),16),parseInt(c.substr(5,2),16)];
  const A=rgb(a),B=rgb(b);
  return "#"+[0,1,2].map(i=>{const v=Math.round(A[i]+(B[i]-A[i])*t);return (v<16?"0":"")+v.toString(16)}).join("");
}
export function colorForHour(h,clampFn,lerpFn) {
  for(let i=1;i<SKY.length;i++){if(h<=SKY[i][0]){const a=SKY[i-1],b=SKY[i];return lerpFn(a[1],b[1],(h-a[0])/(b[0]-a[0]),clampFn);}}
  return SKY[SKY.length-1][1];
}
export function sunProgress(h){return (h>=5.5&&h<=19)?(h-5.5)/13.5:-1;}
export function moonProgress(h){if(h>=18)return (h-18)/12;if(h<6)return (h+6)/12;return -1;}
