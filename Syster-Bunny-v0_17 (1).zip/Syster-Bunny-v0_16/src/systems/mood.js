// Regras de humor separadas da interface e das animações.
export const moodLabels = {
  curiosa: "curiosa", sonolenta: "sonolenta", chateada: "precisando de cuidados",
  tímida: "tímida", carinhosa: "carinhosa", feliz: "feliz", tranquila: "tranquila"
};

export function deriveMood({ energy, fed, clean, trust, memories, darkness }) {
  if (energy < 22 || (darkness > 0.6 && energy < 45)) return "sonolenta";
  if (fed < 22 || clean < 22) return "chateada";
  if (trust < 20) return "tímida";
  if (trust >= 75 && memories.pet + memories.quiet + memories.food >= 8) return "carinhosa";
  if (trust >= 50) return "feliz";
  if (trust >= 30) return "tranquila";
  return "curiosa";
}
