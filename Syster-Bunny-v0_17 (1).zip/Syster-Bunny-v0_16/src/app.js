import { decorationItems as items, foods } from "./data/catalog.js";
import { clamp, pick, FULL_THRESHOLD } from "./core/utils.js";
import { loadTrust, saveTrust, loadGameSave, saveGameSave, loadGameTime, saveGameTime } from "./services/storage.js";
import { deriveMood, moodLabels } from "./systems/mood.js";
import { interpolateColor, colorForHour, sunProgress, moonProgress } from "./systems/sky.js";
import { initSupermarket } from "./features/supermarket.js";
import { initGardenGame } from "./features/garden-game.js";
import { dialogueLines } from "./data/dialogues.js";


var $=function(i){return document.getElementById(i)};
var lastDragEnd=0;
var peekOn=false,peekNext=Date.now()+3000,eat=false,trust=0,fed=40,lastAct=0,lastGap=9e9,flick=0,blink=0,x=205,y=365,goal=null,carrot=false,lock=false,hearts=[],last=0;
  var hop=0,earWiggle=0,yawn=0,nextHop=Date.now()+5000,nextYawn=Date.now()+18000;
  var moodNow="curiosa", memories={quiet:0,food:0,pet:0,play:0}, moodSince=Date.now();
trust=loadTrust(trust);
var stages=[
[20,"Desconfiada","Ela está bem encolhidinha, de orelhas baixas, e só espia de vez em quando. Vá com calma."],
[45,"Curiosa","Ela espia de vez em quando. Parece interessada na sua presença."],
[70,"Receptiva","Ela já sai um pouco do esconderijo e fica por perto."],
[90,"Carinhosa","Ela se aproxima sozinha. Agora aceita mais carinho."],
[101,"Confiante","Ela está solta e feliz ao seu lado."]];
function stg(){for(var i=0;i<stages.length;i++)if(trust<stages[i][0])return i;return 4}
var cur=-1;
function say(t){$("msg").textContent=t}
function add(v){trust=clamp(trust+v,0,100);saveTrust(trust)}
function act(){var n=Date.now();lastGap=n-lastAct;lastAct=n;
if(lastGap<700){add(-1);flick=1;say("Você foi rápido demais. Ela se assustou.")}}
function heart(){hearts.push({x:x+(Math.random()*50-25),y:y-100,l:1})}
function react(kind){
  if(kind==="happy"){hop=Math.max(hop,.48);earWiggle=.55;heart()}
  else if(kind==="shy"){earWiggle=.7;flick=Math.max(flick,.35)}
  else if(kind==="curious"){earWiggle=.4}
}
$("bq").onclick=function(){act();memories.quiet++;lock=true;react("happy");set();add(1.5);sv();say("Você fica parado, sem fazer barulho… ela relaxa um pouquinho.");
setTimeout(function(){lock=false;lastAct=Date.now()-3000;set()},5000)};
$("bc").onclick=function(){if(room==="B"){say("Escolha água fria ou quente e ligue o chuveiro nos controles acima.");return;}if(her!=="Q"){say("Ela não está no quarto agora.");return}if(fed>=FULL_THRESHOLD){say("Estou sem fome agora. Obrigada, mas não quero mais comida!");talk("já estou satisfeita…",2200);return}if(carrot)return;act();memories.food++;react("curious");carrot=true;$("carrot").style.display="";set();
say("Cenoura deixada. Agora afaste-se e não mexa em nada.");wait()};
function wait(){var t=setInterval(function(){
if(!carrot){clearInterval(t);return}
if(Date.now()-lastAct>4000){clearInterval(t);var shy=trust>=15;goal=shy?(x+210)/2:null;if(shy)setTimeout(function(){goal=210;eat=true},1100);
say(trust>=15?"Ela saiu para pegar a cenoura!":"Você não viu, mas a cenoura sumiu…");
setTimeout(function(){carrot=false;eat=false;$("carrot").style.display="none";goal=null;if(fed>=FULL_THRESHOLD){say("Ela já estava satisfeita e deixou a cenoura para depois.");set();return}fed=clamp(fed+30,0,100);add(5);coins+=5;sv();talk(trust>=15?"obrigada…":"…",2400);
say(trust>=15?"Ela comeu e voltou devagar. Ela confia mais em você.":"Alguém comeu quando você não estava olhando. Isso conta como confiança.");set()},3200)}
},400)}
$("bp").onclick=function(){act();memories.pet++;sv();
if(trust<30){add(-1);flick=1;say("Ela estremece e se esconde mais. Ainda é cedo para o toque.")}
else if(trust<60){add(2);react("happy");say("Um toquinho rápido na cabeça. Ela aceita, de olhos fechados.");heart();talk(pick(["…","tá… gostoso."]),2200)}
else{add(3);react("happy");say("Ela se encosta na sua mão, com as bochechas coradas.");heart();heart();talk(pick(["hihi!","mais um pouquinho!"]),2400)}
set()};
$("scene").onclick=function(){if(Date.now()-lastDragEnd<500)return;if(sleeping)return wake();act();if(trust<45){flick=1;add(-0.5);say("Cutucar assusta. Tente ficar quieto ou deixar uma cenoura.")}else{heart();say("Ela inclina a cabeça para você.")}set()};
function updateMood(){
  moodNow=deriveMood({energy,fed,clean,trust,memories,darkness:dark()});
  var line=$("moodline");
  if(line) line.textContent="Humor: "+moodLabels[moodNow];
}

$("btalk").onclick=function(){
if(lock||sleeping)return;
memories.play++;react("curious");sv();
var replies={curiosa:["o que vamos fazer hoje?","você viu aquilo?"],sonolenta:["bocejo… podemos descansar?","estou com soninho…"],chateada:["acho que preciso de um cuidadinho…","pode me ajudar a ficar melhor?"],tímida:["o-oi…","você vai ficar por aqui?"],carinhosa:["gosto muito da sua companhia!","a gente é uma boa dupla, né?"],feliz:["oba! você veio conversar!","hoje está sendo um dia bom!"],tranquila:["gosto desses momentos calminhos.","está tudo bem por aqui."]};
var reply=replies[moodNow]||replies.curiosa;
talk(pick(reply),3000);say("Você conversou com a Syster. Ela parece "+({curiosa:"curiosa",sonolenta:"com sono",chateada:"precisar de atenção",tímida:"um pouco tímida",carinhosa:"mais próxima de você",feliz:"feliz",tranquila:"tranquila"}[moodNow])+".");
};
function set(){updateMood();var dirtLevel=clamp((40-clean)/40,0,1);$("dirtMarks").style.display=dirtLevel>0?"":"none";$("dirtMarks").style.opacity=(dirtLevel*.88).toFixed(2);var i=stg();$("tf").style.width=trust+"%";$("tv").textContent=Math.round(trust)+"%";
$("hf").style.width=fed+"%";$("hv").textContent=Math.round(fed)+"%";$("gf").style.width=clean+"%";$("gv").textContent=Math.round(clean)+"%";$("nf").style.width=energy+"%";$("nv").textContent=Math.round(energy)+"%";if(typeof updShop==="function")updShop();
$("bq").disabled=lock;$("bc").disabled=lock;$("bp").disabled=lock;$("bs").disabled=lock;$("btalk").disabled=lock||sleeping;
if(i!==cur){if(cur>=0&&i>cur&&typeof talk==="function")talk(L.up[i],4000);cur=i;$("stage").textContent="Fase: "+stages[i][1];say(stages[i][2])}}
setInterval(function(){if(Date.now()-lastAct>3000&&!lock&&!carrot)add(0.3+owned.length*0.1+(lampOn&&room==="Q"?0.1:0));if(++saveTick%10===0)sv();fed=clamp(fed-0.3,0,100);clean=clamp(clean-0.15,0,100);if(!sleeping)energy=clamp(energy-(dark()>.6?0.4:0.25),0,100);idle();wander();weather();rainTick();updClock();showerTick();set()},1000);
function draw(ts){var dt=Math.min(.05,(ts-last)/1000||.016);last=ts;var t=trust/100;$("bunny").style.display=(her===room)?"":"none";
var now=Date.now();
if(fanOn){fanAngle=(fanAngle+dt*600)%360;$("fanBlades").setAttribute("transform","rotate("+fanAngle.toFixed(1)+" 287 386)")}
if(!lock&&!sleeping&&!carrot&&now>nextHop){hop=.48;nextHop=now+8500+Math.random()*8500}
if(!lock&&!sleeping&&moodNow==="sonolenta"&&now>nextYawn){yawn=.9;nextYawn=now+9000+Math.random()*7000}
if(hop>0)hop=Math.max(0,hop-dt*2.4);if(earWiggle>0)earWiggle=Math.max(0,earWiggle-dt*1.8);if(yawn>0)yawn=Math.max(0,yawn-dt*1.1);
if(flick>.95){peekOn=false;peekNext=now+5000;if(!stDone){stDone=true;talk(pick(L.startle),1500)}}if(flick<.5)stDone=false;
if(trust<45){if(!peekOn&&now>peekNext&&now-lastAct>2500){peekOn=true;peekNext=now+2200+Math.random()*1500;talk(pick(L.peek),1800)}else if(peekOn&&now>peekNext){peekOn=false;peekNext=now+4000+Math.random()*4000}}
var hide=trust<45&&!peekOn?10*(1-trust/45):0;
var homeX=205+35*clamp((trust-15)/50,0,1),homeY=sleeping?372:365-12*clamp(trust/45,0,1)+hide;
var gx=goal!==null?goal:homeX;x+=(gx-x)*Math.min(1,dt*3);y+=(homeY-y)*Math.min(1,dt*3);
var lying=sleeping&&her==="Q"&&room==="Q"&&Math.abs(x-62)<12;
sleepK=clamp(sleepK+(lying?dt*2.2:-dt*6),0,1);
$("sleepG").style.display=sleepK>0?"":"none";$("sleepG").setAttribute("opacity",sleepK.toFixed(2));
$("bedFront").style.display=sleepK>.05?"":"none";$("bunny").style.opacity=(1-sleepK).toFixed(2);
soapFrame(dt,ts);timeFrame(dt,ts,lying);
var br=1+Math.sin(ts/600)*.02;flick=Math.max(0,flick-dt*1.5);
var hopY=hop>0?-Math.sin((hop/.48)*Math.PI)*17:0;
blink-=dt;if(blink<-3.5)blink=.15;var by=blink>0||flick>.5||sleeping?.15:(energy<25?.55:1);
var sc=(.68+.07*t)*(1-flick*.12),sh=((1-t)*.4+flick*2.5+(wx==="cold"&&!wxOK?1.2:0))*Math.sin(ts/30);
$("bunny").setAttribute("transform","translate("+(x+sh).toFixed(1)+" "+(y+hopY+(eat?Math.sin(ts/110)*2.5:0)).toFixed(1)+") scale("+sc.toFixed(3)+" "+(sc*br).toFixed(3)+")");
$("bub").setAttribute("transform","translate("+clamp(x,bw/2+6,354-bw/2).toFixed(1)+" "+Math.max(34,y-124*sc-26).toFixed(1)+")");var tw=Math.pow(Math.max(0,Math.sin(ts/1100)),12)*10,d=(1-t)*24+flick*22+(wx==="hot"&&!wxOK?14:0);
var twitch=Math.sin(ts/75)*earWiggle*9;
$("earL").setAttribute("transform","rotate("+(-d-twitch)+" -24 -34)");
$("earR").setAttribute("transform","rotate("+(d-tw+twitch)+" 24 -34)");
var er=.75+.35*t,gz=(1-t)*(Math.sin(ts/1300)>.6?0:-3.5),gy=(1-t)*2;
$("eyeL").setAttribute("transform","translate("+(-17+gz).toFixed(1)+" "+(-4+gy).toFixed(1)+") scale("+er.toFixed(2)+" "+(er*by).toFixed(2)+")");
$("eyeR").setAttribute("transform","translate("+(17+gz).toFixed(1)+" "+(-4+gy).toFixed(1)+") scale("+er.toFixed(2)+" "+(er*by).toFixed(2)+")");
var o=clamp(t*1.4-.1+flick*.3+(wx==="hot"&&!wxOK?.5:0),0,1);$("chkL").setAttribute("opacity",o);$("chkR").setAttribute("opacity",o);
var mouthY=moodNow==="feliz"||moodNow==="carinhosa"?27:moodNow==="chateada"?9:moodNow==="sonolenta"?22:15+15*t;
    var foodNear=!!(supermarket&&supermarket.isNearMouth());$("mouth").setAttribute("fill",foodNear?"#c2435f":"none");if(foodNear){$("mouth").setAttribute("d","M-9 17Q0 40 9 17Z");}else if(yawn>0){$("mouth").setAttribute("d","M-5 18 Q0 15 5 18 Q6 27 0 28 Q-6 27 -5 18");}
    else{$("mouth").setAttribute("d","M-8 19Q0 "+mouthY.toFixed(1)+" 8 19");}
    if(moodNow==="sonolenta"){$("eyeL").setAttribute("opacity",".65");$("eyeR").setAttribute("opacity",".65")}else{$("eyeL").setAttribute("opacity","1");$("eyeR").setAttribute("opacity","1")}
var h="";for(var k=hearts.length-1;k>=0;k--){var p=hearts[k];p.y-=dt*30;p.l-=dt*.6;
if(p.l<=0){hearts.splice(k,1);continue}
h+='<text x="'+(p.z?p.x+Math.sin((1-p.l)*7)*7:p.x).toFixed(0)+'" y="'+p.y.toFixed(0)+'" font-size="'+(p.z?(12+(1-p.l)*16).toFixed(0):20)+'" font-weight="'+(p.z?600:400)+'" fill="'+(p.z?"#8fa0ff":p.b?"#6cc3e8":"#ff6f9c")+'" opacity="'+p.l.toFixed(2)+'">'+(p.z?"z":p.b?"○":"♥")+'</text>'}
$("fx").innerHTML=h;
requestAnimationFrame(draw)}
var sleepK=0;
var room="Q",her="Q",bathing=false,clean=60,energy=70,sleeping=false,sz=null,st=null;
var showerOn=false,showerTemp="cold",showerHintAt=0,showerStartedAt=0,fridgeIsOpen=false;
function here(){return her===room}
function fin(){clearInterval(sz);clearTimeout(st);sleeping=false;goal=null;lock=false;$("dim").style.opacity=0}
function sleep(){if(her!=="Q"||room!=="Q"){say("Ela não está aqui agora.");return}act();if(energy>(dark()>.6?92:85)&&!(wx==="cold"&&!wxOK)){say("Ela ainda não está com sono.");return}
var hh0=hour();sleepNight=(hh0>=19||hh0<5.5);sleepMult=sleepNight?Math.max(3,(((6.5-hh0)+24)%24)/24*DAY/8):3;lock=true;sleeping=true;goal=62;$("dim").style.opacity=sleepNight?(lampOn?.1:.2):(lampOn?.3:.55);say("Ela se deita na caminha e se cobre até o queixo. Fique quieto…");talk("boa noite…",2200);set();
sz=setInterval(function(){if(sleepK>.6)hearts.push({x:70+Math.random()*16,y:366,l:1,z:true})},900);
st=setTimeout(function(){fin();energy=clamp(energy+(sleepNight?85:60),0,100);react("happy");add(2);coins+=5;sv();if(wx==="cold"&&!wxOK)resolveWx("Aninhada na caminha, ela se aqueceu toda.");talk("…bom dia.",2600);say("Ela acordou descansada. Dormir perto de você, sem susto, conta como confiança.");set()},9000)}
function wake(){fin();flick=1;add(-1);say("Você acordou ela de repente. Ela se assustou.");set()}
$("bs").onclick=sleep;
var coins=20,owned=[],foodInventory={};
function inventoryTotal(){return Object.keys(foodInventory).reduce(function(n,k){return n+Math.max(0,parseInt(foodInventory[k],10)||0)},0)}

function sv(){saveGameSave({c:coins,o:owned,m:memories,f:foodInventory,n:{fed:fed,clean:clean,energy:energy}})}
var saveTick=0;
var sd=loadGameSave();
if(sd){coins=+sd.c||0;owned=Array.isArray(sd.o)?sd.o:[];if(sd.m)memories={quiet:+sd.m.quiet||0,food:+sd.m.food||0,pet:+sd.m.pet||0,play:+sd.m.play||0};if(sd.f&&typeof sd.f==="object")foodInventory=sd.f;if(sd.n){if(isFinite(sd.n.fed))fed=clamp(+sd.n.fed,0,100);if(isFinite(sd.n.clean))clean=clamp(+sd.n.clean,0,100);if(isFinite(sd.n.energy))energy=clamp(+sd.n.energy,0,100)}}
function renderDec(){items.forEach(function(it){$("d_"+it[0]).style.display=(owned.indexOf(it[0])>-1&&room==="Q")?"":"none"})}
function updShop(){$("coins").textContent="Moedas: "+coins+"  |  Alimentos guardados: "+inventoryTotal()+"  |  Conforto: +"+(owned.length*0.1).toFixed(1)+" por segundo parada  |  Clima: "+({mild:"ameno",hot:"calor"+(wxOK?"":" (ela está com calor)"),cold:"frio"+(wxOK?"":" (ela está com frio)")})[wx];
var bs=$("shop").querySelectorAll("button");for(var i=0;i<bs.length;i++){var k=bs[i].getAttribute("data-k"),it=items.filter(function(q){return q[0]===k})[0],has=owned.indexOf(k)>-1;bs[i].disabled=has||coins<it[2];bs[i].textContent=has?"Comprado":"Comprar"}}
var sh="";items.forEach(function(it){sh+='<div class="item"><span>'+it[1]+' ('+it[2]+' moedas)</span><button data-k="'+it[0]+'">Comprar</button></div>'});$("shop").innerHTML=sh;
$("shop").onclick=function(e){var k=e.target.getAttribute&&e.target.getAttribute("data-k");if(!k)return;var it=items.filter(function(q){return q[0]===k})[0];if(owned.indexOf(k)>-1||coins<it[2])return;coins-=it[2];owned.push(k);sv();renderDec();updShop();say(it[1]+" colocado no quarto. Ela observa de longe, curiosa.");talk("é pra mim?",2200)};
$("nD").onclick=function(){var o=$("shop").hidden;$("shop").hidden=!o;$("nD").setAttribute("aria-expanded",o)};
var supermarket;
function closeMarket(){if(supermarket)supermarket.closeMarket()}

var bw=60,tkT=null,nextIdle=Date.now()+6000,stDone=false;
var L=dialogueLines;

var lampOn=false,fanOn=false,fanAngle=0,wish=null,asking=false,askT=null,nextWander=Date.now()+20000,wishAt=0,traveling=false,travelTimer=null;
function applyLamp(){$("glow").setAttribute("r",lampOn?90:50);$("glow").setAttribute("opacity",lampOn?.35:.2);$("warm").style.opacity=(lampOn&&room==="Q")?(.14+.14*dark()):0}
function toggleLamp(){lampOn=!lampOn;applyLamp();say(lampOn?"A luminária acendeu e o quarto ficou quentinho.":"Você apagou a luminária.");talk(lampOn?"que luz bonita…":"…",2000)}
$("d_lamp").onclick=function(e){e.stopPropagation();toggleLamp()};$("d_lamp").onkeydown=function(e){if(e.key==="Enter"||e.key===" "){e.preventDefault();toggleLamp()}};
function toggleFan(e){if(e)e.stopPropagation();if(room!=="Q"||owned.indexOf("fan")<0)return;fanOn=!fanOn;$("d_fan").setAttribute("aria-label",fanOn?"Desligar ventilador":"Ligar ventilador");say(fanOn?"Você ligou o ventilador. As hélices começaram a girar.":"Você desligou o ventilador.");talk(fanOn?"que ventinho bom!":"o ventinho parou…",2000)}
$("d_fan").onclick=toggleFan;$("d_fan").onkeydown=function(e){if(e.key==="Enter"||e.key===" "){e.preventDefault();toggleFan(e)}};
function roomName(r){return ({Q:"quarto",B:"banheiro",G:"jardim",S:"sala",K:"cozinha"})[r]||"cômodo"}
function whereMsg(r){say(her===r?"Ela está na "+roomName(r)+", olhando tudo com curiosidade.":(trust<30?"Ela ainda está tímida para passear sozinha.":"Ela está em outro cômodo. Você pode chamá-la pelo sino."))}
function ask(){var w=wish;if(!w)return;asking=true;talk(w==="bath"?(wx==="hot"&&!wxOK?"tá quente… posso tomar banho?":"posso tomar banho?"):(wx==="cold"&&!wxOK?"tá frio… posso me aquecer na caminha?":"posso dormir?"),13000);$("ask").hidden=false;askT=setTimeout(function(){endAsk(false)},13000)}
function endAsk(ok){clearTimeout(askT);asking=false;$("ask").hidden=true;var w=wish;wish=null;
if(ok){talk("oba…",1500);if(w==="bath")bath();else sleep()}else{talk("tá… tudo bem.",2000);nextWander=Date.now()+15000;say("Ela entendeu e esperou. Ela não faz nada sem a sua permissão.")}}
function checkWish(){if(!wish||her!==room||asking||lock||sleeping||Date.now()<wishAt)return;ask()}
function wander(){checkWish();var n=Date.now();if(n<nextWander||trust<30||lock||sleeping||carrot||asking||traveling||foam>.02)return;nextWander=n+25000+Math.random()*20000;
var rooms=["Q","B","G","S","K"],choices=rooms.filter(function(code){return code!==her});var to=choices[Math.floor(Math.random()*choices.length)],w=null;
// Necessidades podem influenciar o destino, sem limitar os passeios aos dois primeiros cômodos.
var coolByFan=wx==="hot"&&!wxOK&&fanOn&&owned.indexOf("fan")>-1;
if(coolByFan&&her==="Q"){nextWander=n+8000;return}
if(coolByFan)to="Q";
else if(trust>=45&&(clean<65||(wx==="hot"&&!wxOK)))to="B";
else if(energy<(dark()>.6?80:55)||(wx==="cold"&&!wxOK&&trust>=30))to="Q";
if(to===her)to=choices[Math.floor(Math.random()*choices.length)];
if(to==="B"&&trust>=45&&(clean<65||(wx==="hot"&&!wxOK)))w="bath";
else if(to==="Q"&&(energy<(dark()>.6?80:55)||(wx==="cold"&&!wxOK&&trust>=30)))w="sleep";
wish=w;traveling=true;
var arrive=function(){her=to;wish=w;x=-70;goal=null;wishAt=Date.now()+2200;traveling=false;travelTimer=null;if(her===room)say("Ela chegou! Está no cômodo: "+roomName(her)+".")};
if(her===room){goal=430;travelTimer=setTimeout(arrive,1600)}else arrive()}
$("aY").onclick=function(){endAsk(true)};$("aN").onclick=function(){endAsk(false)};
var wx="mild",wxOK=true,wxEnd=0,wxNext=Date.now()+25000;
function applyWx(){var e=$("wx");e.setAttribute("fill",wx==="hot"?"#ffb347":"#7fb2ff");e.style.opacity=wx==="mild"?0:(wx==="hot"?.14:.2);updClock()}
function resolveWx(why){wxOK=true;add(3);coins+=5;sv();say(why);talk(wx==="hot"?"ahh… melhor.":"mm… quentinho.",2400);set()}
function weather(){var n=Date.now();
if(wx==="mild"){if(n<wxNext)return;wx=Math.random()<.5?"hot":"cold";wxEnd=n+70000;wxOK=false;applyWx();
say(wx==="hot"?"Está fazendo calor! A Syster está abafada. Ela gostaria de se refrescar.":"Esfriou de repente! A Syster está tremendo. Ela gostaria de se aquecer.");talk(pick(L[wx]),2600);return}
if(n>wxEnd){wx="mild";wxOK=true;wxNext=n+60000+Math.random()*60000;applyWx();say("O tempo voltou ao normal.");return}
if(!wxOK){if(wx==="hot"&&owned.indexOf("fan")>-1&&fanOn&&her==="Q")resolveWx("O ventilador refresca o quarto. Ela suspira, aliviada.");
else if(wx==="cold"&&(lampOn||owned.indexOf("blank")>-1))resolveWx(lampOn?"A luminária esquenta o quarto. Ela relaxa.":"A cobertinha a aquece. Ela relaxa.")}}
function talk(s,ms){if(!here())return;var w=Math.max(44,s.length*7.2+24);bw=w;$("bubT").textContent=s;$("bubR").setAttribute("width",w);$("bubR").setAttribute("x",-w/2);$("bub").style.opacity=1;clearTimeout(tkT);tkT=setTimeout(function(){$("bub").style.opacity=0},ms||2600)}
function idle(){var n=Date.now();if(n<nextIdle||lock||sleeping||carrot)return;nextIdle=n+12000+Math.random()*10000;
    var moodLines={feliz:["hihi! estou tão feliz!","que bom ter você por perto!"],curiosa:["o que será aquilo?","estou observando tudo…"],tímida:["posso ficar aqui mais um pouquinho?","…não vá embora."],sonolenta:["bocejo…","meus olhinhos estão pesados…"],chateada:["acho que preciso de um cuidadinho…","hoje não estou no meu melhor dia."],carinhosa:["gosto da sua companhia!","fica mais um pouquinho?"],tranquila:["está tão calminho aqui…","gosto de ficar pertinho." ]};
    talk(ambientLine()||(wxOK||wx==="mild"?pick(moodLines[moodNow]||L.idle[stg()]):pick(L[wx])),2600)}
renderDec();
function bath(){say("Use os controles do chuveiro para escolher a temperatura e ligar a água.");}
function updateShower(){
 $("waterStream").setAttribute("opacity",showerOn?1:0);$("steam").setAttribute("opacity",showerOn&&showerTemp==="hot"?1:0);
 $("showerToggle").textContent=showerOn?"Desligar chuveiro":"Ligar chuveiro";
 $("showerToggle").setAttribute("aria-pressed",String(showerOn));
 $("showerCold").classList.toggle("active",showerTemp==="cold");
 $("showerHot").classList.toggle("active",showerTemp==="hot");
 $("showerCold").setAttribute("aria-pressed",String(showerTemp==="cold"));
 $("showerHot").setAttribute("aria-pressed",String(showerTemp==="hot"));
 var drops=$("waterStream").querySelectorAll("path,ellipse");
 for(var i=0;i<drops.length;i++)drops[i].setAttribute("stroke",showerTemp==="hot"?"#ff9b62":"#6cc3e8");
}
$("showerToggle").onclick=function(){
 showerOn=!showerOn;if(!showerOn)showerStartedAt=0;updateShower();
 say(showerOn?"Chuveiro ligado. Escolha água fria ou quente e observe como ela reage.":"Chuveiro desligado.");
 if(showerOn&&her==="B")goal=270;
};
$("showerCold").onclick=function(){showerTemp="cold";updateShower();say("Você selecionou água fria.");};
$("showerHot").onclick=function(){showerTemp="hot";updateShower();say("Você selecionou água quente.");};
function showerTick(){
 if(!showerOn||her!=="B") {showerStartedAt=0;return;}
 var comfortable=showerComfy();
 if(!comfortable){
   showerStartedAt=0;
   if(Date.now()-showerHintAt>7000){say(showerTemp==="hot"?"A água está quente demais para ela agora.":"A água está fria demais para ela agora.");showerHintAt=Date.now()}
   return;
 }
 if(trust<30){showerStartedAt=0;goal=null;return;}
 goal=270;
 if(foam>.02){showerStartedAt=0;if(Date.now()-showerHintAt>6000){say("Enxaguando a espuma…");talk("a água está boa…",2200);showerHintAt=Date.now()}return}
 if(!showerStartedAt){showerStartedAt=Date.now();say("Ela começou o banho. Só com água ela chega a 70% de limpeza; para ficar 100% use o sabão.");talk("a água está boa…",2200);}
 var elapsed=Date.now()-showerStartedAt;for(var q=0;q<3;q++)hearts.push({x:250+Math.random()*40,y:310+Math.random()*20,l:1,b:true});
 if(elapsed>=7000){
   clean=Math.max(clean,70);showerOn=false;showerStartedAt=0;updateShower();
   react("happy");add(1);coins+=2;sv();
   if(!wxOK&&wx!=="mild")resolveWx(showerTemp==="cold"?"A água fria refrescou a Syster. Ela parece bem melhor!":"A água quente deixou a Syster confortável novamente.");
   else {say("Banho de água terminado. Para deixá-la 100% limpinha, ensaboe com o sabão e enxágue.");talk("prontinha!",2600);}
   set();
 }
}

$("callRoom").onclick=function(){
 if(lock||sleeping){say("Ela precisa terminar o que está fazendo antes de atender.");return}
 if(asking){clearTimeout(askT);asking=false;$("ask").hidden=true;wish=null}
 if(her===room){say("Ela já está neste cômodo!");talk("já estou aqui!",1800);return}
 var destination=room;
 if(travelTimer){clearTimeout(travelTimer);travelTimer=null}traveling=false;wish=null;
 her=destination;x=-55;y=410;goal=100;nextWander=Date.now()+30000;
 say("Você tocou o sino. A Syster está vindo para "+(destination==="Q"?"o quarto":destination==="B"?"o banheiro":destination==="G"?"o jardim":destination==="S"?"a sala":"a cozinha")+".");
 talk("já vou…",1800);
 setTimeout(function(){if(her===destination){goal=null;say("Ela chegou! Agora está com você neste cômodo.");}},1800);
};

// ===== Sabão: ensaboar manualmente e enxaguar com o chuveiro =====
var foam=0,foamPeak=0,foamHint=false,soapDrag=false,soapX=62,soapY=221,soapPrev=null,bubAcc=0,rinseAcc=0,scrubTalkAt=0,soapNoAt=0,bubs=[],lastBh="",foamEls=[];
var SOAP_HOME={x:62,y:221};
(function(){
 var spots=[["B",0,74,13],["H",-26,-24,14],["B",-20,92,12],["H",18,-28,13],["B",20,92,12],["H",-4,-40,12],["B",-12,106,10],["H",34,-6,12],["B",12,106,10],["H",-38,6,11],["B",-40,72,9],["H",8,30,12],["B",40,72,9],["H",-22,26,10],["B",-46,92,9],["H",26,22,10],["B",46,92,9],["H",0,-8,10],["H",-30,-4,9],["B",0,98,11],["H",14,-14,9],["H",-14,-18,9],["B",-22,78,9],["B",22,78,9]];
 spots.forEach(function(sp,i){
  var g=document.createElementNS("http://www.w3.org/2000/svg","g");g.setAttribute("display","none");
  g.innerHTML='<circle r="'+sp[3]+'" fill="#fff" stroke="#9fd6ee" stroke-width="1.6"/><circle cx="'+(-sp[3]*.35).toFixed(1)+'" cy="'+(-sp[3]*.38).toFixed(1)+'" r="'+(sp[3]*.26).toFixed(1)+'" fill="#d9f2ff" stroke="none"/>';
  (sp[0]==="H"?$("foamHead"):$("foamBody")).appendChild(g);
  foamEls.push({g:g,x:sp[1],y:sp[2],t:.04+i*(.86/(spots.length-1)),ph:i*1.7,on:false});
 });
})();
function showerComfy(){return wx==="mild"||wxOK||(wx==="hot"&&showerTemp==="cold")||(wx==="cold"&&showerTemp==="hot")}
function svgPt(e){var sv=$("scene"),pt=sv.createSVGPoint();pt.x=e.clientX;pt.y=e.clientY;var m=sv.getScreenCTM();return m?pt.matrixTransform(m.inverse()):{x:0,y:0}}
function overBunny(px,py){return her==="B"&&px>x-44&&px<x+44&&py>y-36&&py<y+84}
function spawnBubble(px,py,vx,vy,r,k){bubs.push({x:px,y:py,vx:vx,vy:vy,r:r,l:1,k:k})}
function scrub(px,py,d,force){
 var now=Date.now();lastAct=now;
 if(!force&&!overBunny(px,py))return;
 if(trust<30){flick=Math.max(flick,.7);if(now-soapNoAt>3000){soapNoAt=now;say("Ela se encolhe… ainda não confia o bastante para ser ensaboada. Passe mais tempo com ela primeiro.");talk("n-não…",1600)}return}
 nextWander=now+30000;
 if(foam<.02)say("Isso! Continue esfregando o sabão para fazer bolhas.");
 foam=Math.min(1,foam+d*.0042);foamPeak=Math.max(foamPeak,foam);
 earWiggle=Math.max(earWiggle,.25);
 bubAcc+=d;while(bubAcc>6){bubAcc-=6;spawnBubble(px+Math.random()*36-18,py+Math.random()*24-14,Math.random()*26-13,-(14+Math.random()*26),3+Math.random()*7,.55)}
 if(now-scrubTalkAt>3200){scrubTalkAt=now;talk(pick(["hihi, faz cócegas!","que cheirinho bom!","bolhinhas!","aí, aí, aí~","mais um pouquinho!"]),1800);if(Math.random()<.5)heart()}
 if(!foamHint&&foam>.8){foamHint=true;say("Ela está coberta de espuma! Agora ligue o chuveiro para enxaguar.")}
}
function soapStart(e){
 lastDragEnd=Date.now();
 if(room!=="B")return;
 e.preventDefault();e.stopPropagation();
 if(her!=="B"){say("A Syster não está no banheiro. Toque no sino para chamá-la antes de ensaboar.");return}
 if(lock||sleeping){say("Espere a Syster terminar o que está fazendo.");return}
 soapDrag=true;$("soapG").classList.add("dragging");try{$("soapG").setPointerCapture(e.pointerId)}catch(_){}
 var p=svgPt(e);soapX=p.x;soapY=p.y;soapPrev={x:p.x,y:p.y};lastAct=Date.now();
 if(foam<.02)say("Arraste o sabão por cima da Syster para fazer espuma.");
}
function soapMove(e){
 if(!soapDrag)return;e.preventDefault();
 var p=svgPt(e),px=clamp(p.x,16,344),py=clamp(p.y,40,452);soapX=px;soapY=py;
 var d=soapPrev?Math.hypot(px-soapPrev.x,py-soapPrev.y):0;soapPrev={x:px,y:py};
 if(d>0)scrub(px,py,d,false);
}
function soapEnd(){
 lastDragEnd=Date.now();
 if(!soapDrag)return;
 soapDrag=false;soapPrev=null;$("soapG").classList.remove("dragging");
 if(foam>.02&&!foamHint)say("Continue esfregando para fazer mais espuma, ou ligue o chuveiro para enxaguar.");
}
$("soapG").addEventListener("pointerdown",soapStart);
$("soapG").addEventListener("pointermove",soapMove);
$("soapG").addEventListener("pointerup",soapEnd);
$("soapG").addEventListener("pointercancel",soapEnd);
$("soapG").addEventListener("keydown",function(e){
 if(e.key!=="Enter"&&e.key!==" ")return;e.preventDefault();
 if(room!=="B")return;
 if(her!=="B"){say("A Syster não está no banheiro. Toque no sino para chamá-la antes de ensaboar.");return}
 if(lock||sleeping){say("Espere a Syster terminar o que está fazendo.");return}
 scrub(x,y+30,55,true);
});
window.addEventListener("touchmove",function(e){if(soapDrag&&e.cancelable)e.preventDefault()},{passive:false});
function finishRinse(){
 var good=foamPeak>=.5;foamPeak=0;foamHint=false;
 if(good){
  var gain=clean<80;clean=100;if(gain){coins+=10;add(3)}else add(.5);
  showerOn=false;showerStartedAt=0;updateShower();react("happy");sv();
  if(!wxOK&&wx!=="mild")resolveWx(showerTemp==="cold"?"A água fria refrescou a Syster. Ela parece bem melhor!":"A água quente deixou a Syster confortável novamente.");
  else{say("Enxaguada! A Syster está limpinha, cheirosa e sem nenhuma bolha.");talk("cheirosinha!",2600)}
  set();
 }else say("Era só um pouquinho de espuma… ensaboe mais para ela ficar limpinha de verdade.");
}
function soapFrame(dt,ts){
 if(her!=="B"&&foam>0){foam=0;foamPeak=0;foamHint=false}
 // enxágue: a espuma sai com a água do chuveiro
 if(foam>.001&&showerOn&&her==="B"&&showerComfy()&&trust>=30&&Math.abs(x-270)<42){
  foam=Math.max(0,foam-dt*.22);rinseAcc+=dt;
  while(rinseAcc>.07){rinseAcc-=.07;spawnBubble(x+Math.random()*70-35,y-10+Math.random()*60,Math.random()*20-10,30+Math.random()*30,3+Math.random()*5,.9)}
  if(foam<=.001){foam=0;finishRinse()}
 }
 // espuma no corpo
 for(var i=0;i<foamEls.length;i++){var f=foamEls[i],k=clamp((foam-f.t)/.12,0,1);
  if(k<=0){if(f.on){f.g.setAttribute("display","none");f.on=false}continue}
  if(!f.on){f.g.removeAttribute("display");f.on=true}
  f.g.setAttribute("transform","translate("+f.x+" "+f.y+") scale("+(k*(1+.05*Math.sin(ts/260+f.ph))).toFixed(3)+")");
 }
 // sabão volta para a prateleira quando solto
 if(!soapDrag){soapX+=(SOAP_HOME.x-soapX)*Math.min(1,dt*9);soapY+=(SOAP_HOME.y-soapY)*Math.min(1,dt*9)}
 if(room==="B")$("soapG").setAttribute("transform","translate("+soapX.toFixed(1)+" "+soapY.toFixed(1)+")"+(soapDrag?" rotate(-12) scale(1.15)":""));
 // bolhas
 if(bubs.length>80)bubs.splice(0,bubs.length-80);
 var bh="";
 for(var j=bubs.length-1;j>=0;j--){var b=bubs[j];b.x+=b.vx*dt;b.y+=b.vy*dt;b.l-=dt*b.k;if(b.l<=0){bubs.splice(j,1);continue}
  var rr=b.r*(1+(1-b.l)*.25);
  bh+='<circle cx="'+b.x.toFixed(1)+'" cy="'+b.y.toFixed(1)+'" r="'+rr.toFixed(1)+'" fill="#fff" fill-opacity="'+(.35*b.l).toFixed(2)+'" stroke="#7cc9ee" stroke-opacity="'+b.l.toFixed(2)+'" stroke-width="1.5"/><circle cx="'+(b.x-rr*.35).toFixed(1)+'" cy="'+(b.y-rr*.35).toFixed(1)+'" r="'+(rr*.25).toFixed(1)+'" fill="#fff" fill-opacity="'+b.l.toFixed(2)+'"/>';
 }
 if(bh||lastBh)$("soapFx").innerHTML=bh;lastBh=bh;
}

// ===== Dia e noite, janelas e chuva =====
var DAY=420,gameT=DAY*.30,sleepMult=3,sleepNight=false,prevH=-1,lastSky=0,lastSave=0,rain=0,rainOn=false,rainEnd=0,rainNext=Date.now()+45000+Math.random()*60000,storm=false,flashT=0,nextFlash=0,rainbowT=0,wins=[];
gameT=loadGameTime(gameT);
function hour(){return (((gameT%DAY)+DAY)%DAY)/DAY*24}
function dark(){var h=hour();if(h<5||h>=20.5)return 1;if(h<7)return 1-(h-5)/2;if(h<17.5)return 0;return (h-17.5)/3}
function skyCol(h){return colorForHour(h,clamp,interpolateColor)}
function sunProg(h){return sunProgress(h)}
function moonProg(h){return moonProgress(h)}
function skyNow(){var d=dark();return interpolateColor(skyCol(hour()),interpolateColor("#9eadbb","#1e2338",d),rain*.75,clamp)}
function cloudSvg(sc){return '<g class="c"><ellipse cx="0" cy="0" rx="'+16*sc+'" ry="'+6*sc+'"/><ellipse cx="'+-9*sc+'" cy="'+-3*sc+'" rx="'+9*sc+'" ry="'+6.5*sc+'"/><ellipse cx="'+8*sc+'" cy="'+-5*sc+'" rx="'+11*sc+'" ry="'+8*sc+'"/></g>'}
function mkWin(id,x,y,w,h){
 var g=$(id),cid=id+"C",r=Math.min(w,h)*.12,html='<clipPath id="'+cid+'"><rect x="'+x+'" y="'+y+'" width="'+w+'" height="'+h+'" rx="8"/></clipPath><g clip-path="url(#'+cid+')">';
 html+='<rect class="sk" x="'+x+'" y="'+y+'" width="'+w+'" height="'+h+'" fill="#a9d8ef"/><g class="st">';
 [[.15,.2],[.35,.1],[.6,.27],[.82,.12],[.9,.4],[.25,.45],[.7,.5]].forEach(function(q,i){html+='<circle cx="'+(x+q[0]*w).toFixed(1)+'" cy="'+(y+q[1]*h).toFixed(1)+'" r="1.6" fill="#fff"><animate attributeName="opacity" values=".35;1;.35" dur="'+(2+i*.45)+'s" repeatCount="indefinite"/></circle>'});
 html+='</g><g class="sn"><circle r="'+(r*1.8).toFixed(1)+'" fill="#ffe58a" opacity=".35"/><circle r="'+r.toFixed(1)+'" fill="#ffd966" stroke="#f4b942" stroke-width="1"/></g>';
 html+='<g class="mn"><circle r="'+r.toFixed(1)+'" fill="#f6f0d0"/><circle cx="'+(-r*.3).toFixed(1)+'" cy="'+(-r*.2).toFixed(1)+'" r="'+(r*.22).toFixed(1)+'" fill="#e3dcb4"/><circle cx="'+(r*.35).toFixed(1)+'" cy="'+(r*.3).toFixed(1)+'" r="'+(r*.16).toFixed(1)+'" fill="#e3dcb4"/></g>';
 var cs=w/90;html+='<g class="bw" opacity="0" fill="none">';
 [[.40,"#ff6b6b"],[.36,"#ffd166"],[.32,"#6bcb77"],[.28,"#5aa9e6"]].forEach(function(a){var rr=w*a[0],cx=x+w/2,cy=y+h*.92;html+='<path d="M'+(cx-rr).toFixed(1)+' '+cy.toFixed(1)+'A'+rr.toFixed(1)+' '+rr.toFixed(1)+' 0 0 1 '+(cx+rr).toFixed(1)+' '+cy.toFixed(1)+'" stroke="'+a[1]+'" stroke-width="'+Math.max(2.5,w*.03).toFixed(1)+'"/>'});
 html+='</g><g class="cl">'+cloudSvg(cs)+cloudSvg(cs*.75)+'</g><g class="rn" opacity="0">';
 for(var i=0;i<9;i++){var px=x+(i+.5)*w/9;html+='<path class="rainfall" d="M'+px.toFixed(1)+' '+(y-8)+'l-6 '+(h+16)+'" stroke="#c9dff2" stroke-width="1.6" stroke-linecap="round" stroke-dasharray="7 11" style="animation:rainmove .55s linear infinite;animation-delay:-'+(i*.13).toFixed(2)+'s"/>'}
 html+='</g></g><rect x="'+x+'" y="'+y+'" width="'+w+'" height="'+h+'" rx="8" fill="none" stroke="#76533e" stroke-width="5"/><path d="M'+(x+w/2)+' '+y+'v'+h+'M'+x+' '+(y+h/2)+'h'+w+'" stroke="#fff" stroke-width="3" opacity=".9"/><path d="M'+(x+w*.12)+' '+(y+h*.3)+'l'+(w*.16)+' '+(-h*.14)+'" stroke="#fff" stroke-width="3" stroke-linecap="round" opacity=".35"/><rect x="'+(x-5)+'" y="'+(y+h-1)+'" width="'+(w+10)+'" height="8" rx="3" fill="#c98f5a" stroke="#5a2e22" stroke-width="2.5"/>';
 g.innerHTML=html;
 wins.push({id:id,x:x,y:y,w:w,h:h,r:r,g:g,sk:g.querySelector(".sk"),st:g.querySelector(".st"),sn:g.querySelector(".sn"),mn:g.querySelector(".mn"),bw:g.querySelector(".bw"),rn:g.querySelector(".rn"),cl:g.querySelector(".cl"),cs:g.querySelectorAll(".c")});
}
mkWin("wQ",250,50,76,90);mkWin("wS",35,65,92,100);mkWin("wK",56,20,100,78);
(function(){ // estrelas, nuvens, chuva e vaga-lumes do jardim
 var sv="",i;for(i=0;i<24;i++){sv+='<circle cx="'+(10+Math.random()*340).toFixed(0)+'" cy="'+(8+Math.random()*200).toFixed(0)+'" r="'+(1+Math.random()*1.6).toFixed(1)+'" fill="#fff"><animate attributeName="opacity" values=".3;1;.3" dur="'+(1.8+Math.random()*3).toFixed(1)+'s" repeatCount="indefinite"/></circle>'}
 $("gStars").innerHTML=sv;$("gStars").setAttribute("opacity",0);
 $("gClouds").innerHTML=cloudSvg(2.1)+cloudSvg(1.5)+cloudSvg(2.6)+cloudSvg(1.8);
 var rv="";for(i=0;i<26;i++){var rx=(i*14+Math.random()*10).toFixed(0);rv+='<path class="rainfall" d="M'+rx+' -20l-30 490" stroke="#d6e9fb" stroke-opacity=".75" stroke-width="2" stroke-linecap="round" stroke-dasharray="10 22" style="animation:rainmove .5s linear infinite;animation-delay:-'+(Math.random()*.5).toFixed(2)+'s"/>'}
 $("gRain").innerHTML=rv;
 var fv='<g id="gFire" opacity="0">';[[70,300],[130,350],[200,320],[260,372],[310,310],[100,410],[230,420]].forEach(function(q,k){fv+='<g><circle cx="'+q[0]+'" cy="'+q[1]+'" r="5" fill="#fff59a" opacity=".3"/><circle cx="'+q[0]+'" cy="'+q[1]+'" r="2.2" fill="#fff59a"/><animate attributeName="opacity" values=".15;1;.15" dur="'+(2+k*.55).toFixed(1)+'s" repeatCount="indefinite"/><animateTransform attributeName="transform" type="translate" values="0 0;8 -9;-6 -4;0 0" dur="'+(6+k)+'s" repeatCount="indefinite"/></g>'});
 $("rG").insertAdjacentHTML("beforeend",fv+'</g>');
})();
function updSky(ts,force){
 var n=ts;if(!force&&n-lastSky<150)return;lastSky=n;
 var h=hour(),d=dark(),sc=skyNow(),sp=sunProg(h),mp=moonProg(h),tnow=Date.now();
 var bow=(rainbowT>tnow&&d<.5)?clamp((rainbowT-tnow)/4000,0,1)*(1-rain):0;
 var starO=clamp((d-.45)/.4,0,1)*(1-rain*.8),cF=interpolateColor(interpolateColor("#ffffff","#5b6488",d),interpolateColor("#8b97a6","#2c3150",d),rain);
 var vis={wQ:room==="Q",wS:room==="S",wK:room==="K"};
 wins.forEach(function(w){
  w.g.style.display=vis[w.id]?"":"none";if(!vis[w.id])return;
  w.sk.setAttribute("fill",sc);w.st.setAttribute("opacity",starO.toFixed(2));
  if(sp<0)w.sn.style.display="none";else{w.sn.style.display="";w.sn.setAttribute("transform","translate("+(w.x+sp*w.w).toFixed(1)+" "+(w.y+w.h*(.82-.62*Math.sin(Math.PI*sp))).toFixed(1)+")");w.sn.setAttribute("opacity",(1-rain*.85).toFixed(2))}
  if(mp<0||d<.45)w.mn.style.display="none";else{w.mn.style.display="";w.mn.setAttribute("transform","translate("+(w.x+mp*w.w).toFixed(1)+" "+(w.y+w.h*(.82-.62*Math.sin(Math.PI*mp))).toFixed(1)+")");w.mn.setAttribute("opacity",(1-rain*.85).toFixed(2))}
  w.bw.setAttribute("opacity",bow.toFixed(2));w.rn.setAttribute("opacity",rain.toFixed(2));w.cl.setAttribute("fill",cF);w.cl.setAttribute("opacity",(.8+rain*.2).toFixed(2));
  for(var i=0;i<w.cs.length;i++){var sp2=i?3.4:2.1,span=w.w*1.5;w.cs[i].setAttribute("transform","translate("+(w.x+(((gameT*sp2+i*w.w*.7)%span)+span)%span-w.w*.25).toFixed(1)+" "+(w.y+w.h*(i?.58:.26)).toFixed(1)+")")}
 });
 if(room==="G"){
  $("gSky").setAttribute("fill",sc);$("gStars").setAttribute("opacity",starO.toFixed(2));
  if(sp<0)$("gSun").style.display="none";else{$("gSun").style.display="";$("gSun").setAttribute("transform","translate("+(30+sp*300).toFixed(1)+" "+(230-185*Math.sin(Math.PI*sp)).toFixed(1)+")");$("gSun").setAttribute("opacity",(1-rain*.85).toFixed(2))}
  if(mp<0||d<.45)$("gMoon").style.display="none";else{$("gMoon").style.display="";$("gMoon").setAttribute("transform","translate("+(30+mp*300).toFixed(1)+" "+(230-185*Math.sin(Math.PI*mp)).toFixed(1)+")");$("gMoon").setAttribute("opacity",(1-rain*.85).toFixed(2))}
  $("gClouds").setAttribute("fill",cF);$("gClouds").setAttribute("opacity",(.8+rain*.2).toFixed(2));
  var cc=$("gClouds").querySelectorAll(".c"),spd=[3,5,2,4],yy=[45,90,135,70];
  for(var i=0;i<cc.length;i++){var span=520;cc[i].setAttribute("transform","translate("+((((gameT*spd[i]+i*130)%span)+span)%span-80).toFixed(1)+" "+yy[i]+")")}
  $("gBow").setAttribute("opacity",bow.toFixed(2));$("gFire").setAttribute("opacity",(clamp((d-.5)/.4,0,1)*(1-rain)).toFixed(2));
 }
 $("gRain").style.display=(room==="G"&&rain>.02)?"":"none";$("gRain").setAttribute("opacity",(rain*.9).toFixed(2));
 var t=d*(room==="Q"?.46:.3)+rain*.1;if(room==="Q"&&lampOn)t=d*.46*.55+rain*.1;
 $("nightTint").style.opacity=clamp(t,0,.6).toFixed(2);
 if(lampOn&&room==="Q")$("warm").style.opacity=(.14+.14*d).toFixed(2);
}
function updClock(){var h=hour(),hh=Math.floor(h),mm=Math.floor((h-hh)*60);var lab=h<5?"Madrugada":h<12?"Manhã":h<18?"Tarde":h<20?"Entardecer":"Noite";
 var ic=rain>.3?"🌧️":(dark()>.6?"🌙":((h>=5&&h<7.5)||(h>=17.5&&h<20)?"🌅":"☀️"));
 $("clockline").textContent=ic+" "+lab+" · "+(hh<10?"0":"")+hh+":"+(mm<10?"0":"")+mm+(rainOn?" · chovendo":"")+(wx==="hot"?" · calor ☀":wx==="cold"?" · frio ❄":"")}
function ambientLine(){if(rainOn&&Math.random()<.5)return pick(["adoro o barulhinho da chuva…","tá chovendo, que gostoso!","olha as gotinhas na janela!"]);if(dark()>.6&&Math.random()<.4)return pick(["que noite bonita…","as estrelas piscam!","estou ficando com sono…"]);return null}
function rainTick(){var n=Date.now();
 if(!rainOn&&n>rainNext){rainOn=true;storm=Math.random()<.3;rainEnd=n+35000+Math.random()*40000;nextFlash=n+4000+Math.random()*6000;
  if(gardenGame&&gardenGame.isActive())gardenGame.finishGame();
  say(storm?"Uma tempestade chegou! Dá para ver a chuva forte pela janela.":"Começou a chover! Dá para ver as gotinhas na janela.");
  if(here()&&!sleeping)talk(pick(["tá chovendo!","ouvi uma gotinha…","que barulhinho…"]),2600);
  if(wx==="hot"&&!wxOK)resolveWx("A chuva refrescou o ar. Ela suspira, aliviada.");
 }else if(rainOn&&n>rainEnd){rainOn=false;storm=false;rainNext=n+100000+Math.random()*120000;
  if(dark()<.5){rainbowT=n+30000;say("A chuva passou e apareceu um arco-íris! 🌈")}else say("A chuva passou.");
  if(here()&&!sleeping)talk("parou de chover!",2000);
 }
}
function dawnEvt(){say("Amanheceu! O sol está nascendo."+(fed<60?" A Syster acordou com fome.":""));if(here()&&!sleeping)talk(fed<60?"bom dia… tô com fome":"bom dia!",2600)}
function duskEvt(){say("Anoiteceu. As estrelas estão aparecendo…");if(here()&&!sleeping)talk("ficou escurinho…",2400)}
function timeFrame(dt,ts,lying){
 gameT+=dt*(lying?sleepMult:1);
 rain+=((rainOn?1:0)-rain)*Math.min(1,dt*.8);
 var now=Date.now();
 if(rainOn&&storm&&rain>.6&&now>nextFlash){flashT=1;nextFlash=now+6000+Math.random()*9000;if(here()&&!sleeping){flick=Math.max(flick,.6);talk(pick(["ah! um trovão!","eek!"]),1600)}}
 flashT=Math.max(0,flashT-dt*3);$("flash").setAttribute("opacity",(flashT*.5).toFixed(2));
 var h=hour();if(prevH>=0&&h>prevH){if(prevH<6&&h>=6)dawnEvt();if(prevH<19.5&&h>=19.5)duskEvt()}prevH=h;
 updSky(ts,false);
 if(now-lastSave>5000){lastSave=now;saveGameTime(gameT)}
}
var gardenGame;

function go(r){
 if(gardenGame&&gardenGame.isActive())gardenGame.stopGame();
 room=r;var b=r==="B",k=r==="K";if(!k){closeMarket();setFridge(false)}
 $("gamePanel").hidden=r!=="G";
 if(r==="G"){$("gameFinish").textContent="";$ ("gameClose").hidden=true;}
 ["rB","rG","rS","rK"].forEach(function(id){$(id).style.display="none"});
 if(b)$("rB").style.display="";if(r==="G")$("rG").style.display="";if(r==="S")$("rS").style.display="";if(k)$("rK").style.display="";
 $("shower").style.display=b?"":"none";$("soapG").style.display=b?"":"none";$("soapFx").style.display=b?"":"none";$ ("showerControls").hidden=!b;
 $("kitchenControls").hidden=!k;$("bedBack").style.display=r==="Q"?"":"none";
 $("d_blank").style.display=(r==="Q"&&owned.indexOf("blank")>-1)?"":"none";
 $("carrot").style.display=(r==="Q"&&carrot)?"":"none";
 $("bc").style.display=b?"":"none";$("bc").textContent="Usar chuveiro";
 $("bs").style.display=r==="Q"?"":"none";
 ["Q","B","G","S","K"].forEach(function(code){$("n"+code).setAttribute("aria-pressed",String(r===code))});
 updateShower();renderDec();$("scene").setAttribute("aria-label",({Q:"Quarto",B:"Banheiro",G:"Jardim",S:"Sala",K:"Cozinha"})[r]+" da Syster Bunny");
 updSky(performance.now(),true);updClock();whereMsg(r);if(b)$("msg").textContent+=" Arraste o sabão 🧼 até ela para ensaboar e depois ligue o chuveiro para enxaguar.";applyLamp();wishAt=Date.now()+2000;
 if(asking){clearTimeout(askT);asking=false;$("ask").hidden=true}
 if(b&&her==="B")talk("o banheiro é grande…",2400);
 if(r==="G"&&her==="G")talk("que jardim bonito!",2400);
 if(r==="S"&&her==="S")talk("gosto deste cantinho…",2400);
 if(k&&her==="K")talk("o que será que tem na despensa?",2400);
}
$("nQ").onclick=function(){go("Q")};$("nB").onclick=function(){go("B")};$("nG").onclick=function(){go("G")};$("nS").onclick=function(){go("S")};$("nK").onclick=function(){go("K")};
function setFridge(open){fridgeIsOpen=open;$("fridgeOpen").style.display=open?"":"none";$("fridgePanel").hidden=!open;$("fridgeG").setAttribute("aria-expanded",String(open))}
function toggleFridge(e){if(e)e.stopPropagation();if(e&&e.target&&e.target.closest&&e.target.closest("[data-drag]"))return;if(Date.now()-lastDragEnd<500)return;if(room!=="K")return;var o=!fridgeIsOpen;setFridge(o);if(o){supermarket.renderPantry();var n=inventoryTotal();say(n>0?"Você abriu a geladeira. Veja os alimentos guardados!":"Você abriu a geladeira. Ela está vazia. Compre alimentos no supermercado!");if(her==="K")talk(n>0?"tem cenouras?":"hmm… vazia…",2000)}else say("Você fechou a geladeira.")}
$("fridgeG").onclick=toggleFridge;$("fridgeG").onkeydown=function(e){if(e.key==="Enter"||e.key===" "){e.preventDefault();toggleFridge(e)}};
$("fridgeClose").onclick=function(){setFridge(false)};


supermarket=initSupermarket({
  $: $, foods: foods,
  getState: function(){return {room:room,her:her,coins:coins,foodInventory:foodInventory,lock:lock,sleeping:sleeping,fed:fed,eat:eat,memories:memories,lastDragEnd:lastDragEnd};},
  setCoins: function(value){coins=value;}, setFed: function(value){fed=value;}, setEat: function(value){eat=value;},
  setLastDragEnd: function(value){lastDragEnd=value;},
  actions: {say:say,talk:talk,act:act,add:add,react:react,sv:sv,set:set,pick:pick,clamp:clamp,updShop:function(){updShop();}}
});
gardenGame=initGardenGame({
  $: $,
  getState: function(){return {room:room,her:her,rainOn:rainOn,lock:lock,sleeping:sleeping};},
  onReward: function(coinsEarned, trustEarned){coins+=coinsEarned;add(trustEarned);memories.play+=1;sv();set();},
  say:say,react:react,talk:talk,pick:pick
});

updateShower();go("Q");set();requestAnimationFrame(draw);
